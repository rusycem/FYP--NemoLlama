#!/usr/bin/env python3
# tts_runner.py
import sys
import time
import torch
import soundfile as sf
from nemo.collections.tts.models import FastPitchModel, HifiGanModel

# ---------- CONFIG ----------
FASTPITCH_NAME = "tts_en_fastpitch_multispeaker"
HIFIGAN_NAME   = "tts_en_hifitts_hifigan_ft_fastpitch"
SAMPLE_RATE = 44100
USE_NGC_PRETRAINED = True   # True -> from_pretrained(), False -> restore_from(local .nemo)
# ----------------------------

def model_supports_emotion(model):
    """Safe check whether model has an 'emotion' input type or supports emotion."""
    inp = getattr(model, "input_types", None)
    if not inp:
        return False
    try:
        return "emotion" in inp
    except Exception:
        return False

def run_tts(text: str, speaker: int, outfile: str, emotion: str = None):
    start_total = time.perf_counter()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[tts_runner] device: {device}, speaker: {speaker}, emotion: {emotion}")

    # ---------- LOAD MODELS ----------
    t0 = time.perf_counter()
    if USE_NGC_PRETRAINED:
        spec_generator = FastPitchModel.from_pretrained(FASTPITCH_NAME)
        vocoder = HifiGanModel.from_pretrained(HIFIGAN_NAME)
    else:
        spec_generator = FastPitchModel.restore_from(FASTPITCH_NAME + ".nemo")
        vocoder = HifiGanModel.restore_from(HIFIGAN_NAME + ".nemo")
    print(f"[timer] Model load: {time.perf_counter() - t0:.3f}s")

    # Eval & move to device if possible
    spec_generator.eval()
    vocoder.eval()
    try:
        spec_generator = spec_generator.to(device)
        vocoder = vocoder.to(device)
    except Exception:
        pass

    # ---------- PARSE TEXT ----------
    t1 = time.perf_counter()
    parsed = spec_generator.parse(text)
    print(f"[timer] Text parse: {time.perf_counter() - t1:.3f}s")

    # Build kwargs for generate_spectrogram
    gen_kwargs = {"speaker": speaker}
    if emotion and model_supports_emotion(spec_generator):
        gen_kwargs["emotion"] = emotion
    elif emotion:
        print("[tts_runner] note: emotion provided but not supported; ignoring.")

    # ---------- GENERATE SPECTROGRAM ----------
    t2 = time.perf_counter()
    with torch.no_grad():
        spectrogram = spec_generator.generate_spectrogram(tokens=parsed, **gen_kwargs)
    print(f"[timer] Spectrogram gen: {time.perf_counter() - t2:.3f}s")

    # ---------- VOCODER ----------
    t3 = time.perf_counter()
    with torch.no_grad():
        audio = vocoder.convert_spectrogram_to_audio(spec=spectrogram)
    print(f"[timer] Vocoder gen: {time.perf_counter() - t3:.3f}s")

    # ---------- SAVE AUDIO ----------
    t4 = time.perf_counter()
    wav = audio.detach().cpu().numpy()
    if wav.ndim > 1 and wav.shape[0] == 1:
        wav = wav.squeeze(0)
    sf.write(outfile, wav, SAMPLE_RATE)
    print(f"[timer] Save audio: {time.perf_counter() - t4:.3f}s")

    # ---------- TOTAL ----------
    print(f"[tts_runner] saved: {outfile} (sr={SAMPLE_RATE})")
    print(f"[timer] TOTAL elapsed: {time.perf_counter() - start_total:.3f}s")

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python3 tts_runner.py \"<text>\" <speaker_id> <outfile.wav> [emotion]")
        sys.exit(1)

    text = sys.argv[1]
    speaker = int(sys.argv[2])
    outfile = sys.argv[3]
    emotion = sys.argv[4] if len(sys.argv) > 4 else None

    run_tts(text, speaker, outfile, emotion)
