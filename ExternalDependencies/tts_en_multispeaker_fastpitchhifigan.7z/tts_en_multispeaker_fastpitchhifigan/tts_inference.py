# tts_inference.py
import torch
import soundfile as sf
from nemo.collections.tts.models import FastPitchModel, HifiGanModel

# ---------- CONFIG ----------
FASTPITCH_NAME = "tts_en_fastpitch_multispeaker"   # or local .nemo file path
HIFIGAN_NAME   = "tts_en_hifitts_hifigan_ft_fastpitch"  # or local .nemo file path
TEXT = "Hello! This is a test of multi-speaker FastPitch with HiFi-GAN and emotions."
SPEAKER_ID = 1   # 1-20 for this model
SAMPLE_RATE = 44100
USE_NGC_PRETRAINED = True   # True -> from_pretrained(), False -> restore_from(local .nemo)
# ----------------------------

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device)

# Load models (either from NGC or local .nemo file)
if USE_NGC_PRETRAINED:
    spec_generator = FastPitchModel.from_pretrained(FASTPITCH_NAME)
    vocoder = HifiGanModel.from_pretrained(HIFIGAN_NAME)
else:
    spec_generator = FastPitchModel.restore_from(FASTPITCH_NAME + ".nemo")
    vocoder = HifiGanModel.restore_from(HIFIGAN_NAME + ".nemo")

# Put models in eval mode and move to device
spec_generator.eval()
vocoder.eval()
try:
    spec_generator = spec_generator.to(device)
    vocoder = vocoder.to(device)
except Exception:
    # Some NeMo models handle device routing internally; ignore if .to() unsupported
    pass

# Inference (no grad)
with torch.no_grad():
    # Parse text into tokens (uses model's tokenizer)
    parsed = spec_generator.parse(TEXT)   # returns tokenized input expected by generate_spectrogram
    # Generate mel spectrogram (ensure using eval mode)
    spectrogram = spec_generator.generate_spectrogram(tokens=parsed, speaker=SPEAKER_ID)

    # Convert spectrogram to audio (vocoder)
    audio = vocoder.convert_spectrogram_to_audio(spec=spectrogram)

# audio is a torch.Tensor; detach and move to CPU before converting to numpy
wav = audio.detach().cpu().numpy()
# Remove batch dim if present
if wav.ndim > 1 and wav.shape[0] == 1:
    wav = wav.squeeze(0)

# Save output
sf.write("audio.wav", wav, SAMPLE_RATE)
print("Saved audio.wav (sr=%d)" % SAMPLE_RATE)
